# 8° lezione database

Materia: Database
REVISIONATA : No
Status: Done

# Le viste in SQL

Oltre alle tabelle di base che fanno parte dello schema si possono creare delle t**abelle ausiliarie virtuali.**

Sono “virtuali” in quanto sembrano tabelle a tutti gli effetti ma sono delle relazioni “create al volo”

Hanno vari utilizzi come:

**– Semplificazione
– Protezione dati
– Scomposizione query complesse
– Riorganizzazione dati secondo nuovi schemi**

## Come si definisce una VIEW

```sql
CREATE VIEW NomeVista
[“(” Attributo {,Attributo} “)”]
AS Query-Select
```

### Esempio

```sql
CREATE VIEW MediaVoti (Matricola,Media) AS
SELECT Matricola, AVG(Voto)
FROM Esami
GROUP BY Matricola

SELECT *
FROM MediaVoti
```

```sql

-- query errata perchè AVG deve agire sui valori di un attributo
SELECT AVG(COUNT(*))
FROM AGENTI
GROUP BY ZONE
```

```sql
CREATE VIEW AgPerZona (Zona,NumAg)
AS
SELECT Zona,COUNT(*)
FROM AGENTI
GROUP BY Zona

SELECT AVG(NumAg)
FROM AgPerZona

SELECT AVG(NumAg)
FROM (SELECT Zona,COUNT(*) as NumAg
FROM AGENTI
GROUP BY Zona)
```

### Uso delle viste per motivi di sicurezza

```sql
CREATE VIEW EsamiPubblici AS
SELECT Corso,Voto
FROM Esami

SELECT Nome, Media
FROM Studenti, MediaVoti
WHERE Studenti.Matricola = MediaVoti.Matricola
```

Data la tabella
ClientiBanca(Nome,Indirizzo,Saldo)

```sql
CREATE VIEW ClientiInd
AS SELECT Nome,Indirizzo
FROM ClientiBanca
```

## Come sono utilizzate le VIEWS

**Le VIEW possono essere usate come tabelle**

```sql
SELECT Nome, Media
FROM Studenti, MediaVoti
WHERE Studenti.Matricola = MediaVoti.Matricola
```

Una VIEW può essere definita sulla base di un’altra VIEW. 

Se una tabella usata in una VIEW viene alterata o cancellata in base al DBMS possono succedere:

- **la VIEW viene marcata ‘inoperative’, oppure**
- **La modifica/cancellazione viene negata**

## Organizzazione  dei dati tramite le VIEWS

**Agenti(CodiceAgente, Nome, Zona, Commissione, Supervisore)**

Assegnare un Supervisore ad una zona intera invece del singolo agente

```sql
-- 1°) 
CREATE TABLE Zone (Zona CHAR(8), Supervisore CHAR(3))
AS SELECT DISTINCT Zona,Supervisore
FROM Agenti

-- 2°)
CREATE TABLE NuoviAgenti
AS SELECT CodiceAgente,Nome,Zona,Commissione
FROM Agenti

-- 3°)
DROP Agenti

-- 4°)
CREATE VIEW Agenti
AS SELECT *
FROM NuoviAgenti NATURAL JOIN Zone
```

Le operazioni `INSERT/UPDATE/DELETE` sulle VIEW non erano permesse nelle prime edizioni di SQL.  I nuovi DBMS permettono di farlo con *certe limitazioni* dovute alla definizione della VIEW stessa.

## Esempi di query con le viste

**AEROPORTO(Città, Nazione,NumPiste)
VOLO(IdVolo,GiornoSett,CittaPart,OraPart,CittaArr,OraArr,TipoAereo)
AEREO(TipoAereo,NumPasseggeri,QtaMerci)**

**scrivere, facendo uso di una vista, l'interrogazione SQL che permette di determinare il massimo numero di passeggeri che possono arrivare in un aeroporto italiano dalla Francia di giovedì (se vi sono più voli, si devono sommare i passeggeri).**

```sql
CREATE VIEW Passeggeri(Numero)
AS SELECT SUM( NumPasseggeri )
FROM AEROPORTO AS A1 JOIN VOLO ON A1.Citta=CittaPart
JOIN AEROPORTO AS A2 ON A2.Citta=CittaArr
JOIN AEREO ON VOLO.TipoAereo=Aereo.TipoAereo
WHERE A1.Nazione=‘Francia’ AND A2.Nazione=’Italia’ AND GiornoSett=’Giovedì’
GROUP BY A2.Citta

SELECT MAX(Numero)
FROM Passeggeri
```

**Definire una vista che mostri per ogni dipartimento il valore medio degli stipendi superiori alla media del dipartimento**

```sql
CREATE VIEW SalariSopraMedia (Dipartimento,Stipendio)
AS SELECT Dipartimento, AVG(Stipendio)
FROM Impiegato AS I
WHERE Stipendio > (
SELECT AVG(I2.Stipendio)
FROM Impiegato AS I2
WHERE I.Dipartimento=I2.Dipartimento)
GROUP BY I.Dipartimento
```

**Definire sulla tabella Impiegato il vincolo che il dipartimento Amministrazione abbia meno di 100 dipendenti, con uno stipendio medio superiore ai 40 mila€.**

```sql
CHECK (100 >= ( SELECT COUNT(*)
FROM Impiegato
WHERE Dipartimento=’Amministrazione’ )
AND 40000 <= (SELECT AVG(Stipendio)
							FROM Impiegato
							WHERE Dipartimento=’Amministrazione’))
```

**Definire a livello di schema il vincolo che il massimo degli stipendi degli impiegati di dipartimenti con sede a Firenze sia minore dello stipendio di tutti gli impiegati del dipartimento Direzione.**

```sql
CREATE ASSERTION ControlloSalari
CHECK ( NOT EXISTS ( SELECT *
FROM Impiegato I JOIN Dipartimento D ON I.Dipartimento=D.Nome
WHERE D.Città=’Firenze’
AND Stipendio > ( SELECT MIN(Stipendio)
FROM Impiegato
WHERE Dipartimento=’Direzione’) ) )
```

# I limiti dell’algebra relazionale

L'algebra relazionale fornisce un insieme robusto e potente di strumenti per formulare interrogazioni sui database, permettendo di esprimere una vasta gamma di operazioni e filtri sui dati. Tuttavia, presenta alcuni limiti, che impediscono di esprimere certi tipi di interrogazioni interessanti.

1. **Mancanza di calcoli sui valori derivati**:
    - L’algebra relazionale permette di estrarre e manipolare dati esistenti, ma non consente di calcolare nuovi valori direttamente.
    - Non possiamo, ad esempio, eseguire operazioni aritmetiche (come somme, differenze, conversioni) su singoli valori o tuple durante l’interrogazione.
    - Questo limite si applica anche agli insiemi di tuple: non è possibile calcolare aggregazioni come somme, medie, conteggi, minimi o massimi senza estensioni all’algebra di base.
    - In SQL, invece, queste operazioni sono supportate tramite le funzioni di aggregazione (`SUM`, `AVG`, `COUNT`, etc.), che rappresentano estensioni rispetto alle operazioni standard dell'algebra relazionale.
2. **Assenza di interrogazioni ricorsive**:
    - **L'algebra relazionale non supporta interrogazioni ricorsiv**e, necessarie per calcoli complessi come la chiusura transitiva.
    - **La chiusura transitiva** è un esempio comune di interrogazione ricorsiva: si tratta di calcolare tutti i collegamenti indiretti tra elementi di un insieme, ad esempio per individuare tutti i possibili percorsi in una rete o tutti i livelli di gerarchia in una struttura ad albero.
    - SQL ha estensioni per gestire questo tipo di interrogazioni, come le *C**ommon Table Expressions* (CTE) ricorsive**, che permettono di esprimere calcoli ricorsivi come la chiusura transitiva.

Questi limiti dell'algebra relazionale hanno portato allo sviluppo di estensioni e linguaggi di interrogazione come SQL, che includono funzioni di aggregazione e meccanismi per eseguire operazioni ricorsive.

## Chiusura transitiva

**Supervisione(Impiegato, Capo)**

![Screenshot 2024-11-07 at 21.10.16.png](8%C2%B0%20lezione%20database%20133c5c8ba93980cbb561d2bf9dd046e3/Screenshot_2024-11-07_at_21.10.16.png)

Per calcolare la chiusura transitiva nella relazione di supervisione tra impiegati e superiori, è necessario ottenere, per ciascun impiegato, tutti i suoi superiori diretti e indiretti (ovvero il capo, il capo del capo, e così via). Questo tipo di calcolo richiede una *query ricorsiva*, che può essere eseguita utilizzando un join ricorsivo della tabella con se stessa.

![Screenshot 2024-11-07 at 21.12.08.png](8%C2%B0%20lezione%20database%20133c5c8ba93980cbb561d2bf9dd046e3/Screenshot_2024-11-07_at_21.12.08.png)

![Screenshot 2024-11-07 at 21.12.21.png](8%C2%B0%20lezione%20database%20133c5c8ba93980cbb561d2bf9dd046e3/Screenshot_2024-11-07_at_21.12.21.png)

Non esiste in algebra e calcolo relazionale la possibilità di esprimere l'interrogazione che, per ogni relazione binaria, ne calcoli la chiusura transitiva.
Per ciascuna relazione, è possibile calcolare la chiusura transitiva, ma con un'espressione ogni volta diversa.

### Quanti join servono?

Non c’è limite

## Soluzione ricorsiva

```sql
WITH RECURSIVE factorial (n, fact) AS
(
	SELECT 0, 1 -- Initial Subquery
	UNION ALL
	SELECT n+1, (n+1)*fact
	FROM factorial -- Recursive Subquery
	WHERE n < 9
)

SELECT * FROM factorial;
```

**Per ogni persona, trovare tutti gli antenati, avendo**

**Paternità (Padre, Figlio)**

```sql
WITH RECURSIVE Discendenza(Antenato,Discendente) AS
(
	SELECT Padre, Figlio
	FROM Paternita
	UNION ALL
	SELECT D.Antenato, Figlio
	FROM Discendenza D, Paternita
	WHERE D.Discendente = Padre
)
SELECT * FROM Discendenza;
```

## Funzioni scalari

Le **funzioni scalari** sono funzioni che operano su singole righe (o ennuple) e restituiscono un singolo valore per ogni riga su cui vengono applicate. Queste funzioni sono ampiamente utilizzate nelle query SQL per manipolare dati a livello di riga. Ecco alcune delle principali categorie di funzioni scalari in SQL:

- **Funzioni temporali**
    
    Le funzioni temporali lavorano su dati di tipo data e ora, permettendo di estrarre o manipolare informazioni temporali.
    
    - **`CURRENT_DATE`**: Restituisce la data corrente.
    
    ```sql
    SELECT CURRENT_DATE;
    -- Esempio output: 2024-11-07
    ```
    
    - **`EXTRACT(part FROM data)`**: Permette di estrarre una parte specifica di una data, come l'anno, il mese o il giorno.
        
        ```sql
        SELECT EXTRACT(YEAR FROM '2024-11-07'::DATE) AS anno;
        -- Esempio output: 2024
        ```
        
- **Funzioni di Manipolazione delle Stringhe**
    
    Queste funzioni permettono di lavorare sui valori di tipo stringa, eseguendo operazioni come la modifica della lunghezza, la conversione di maiuscole/minuscole, e altre manipolazioni di testo.
    
    - **`CHAR_LENGTH(stringa)`**: Restituisce la lunghezza di una stringa in caratteri.
    
    ```sql
    SELECT CHAR_LENGTH('Ciao mondo') AS lunghezza;
    -- Esempio output: 10
    ```
    
    - **`LOWER(stringa)`**: Converte tutti i caratteri di una stringa in minuscolo.
    
    ```sql
    SELECT LOWER('CIAO MONDO') AS minuscolo;
    -- Esempio output: "ciao mondo"
    ```
    
    - **`UPPER(stringa)`**: Converte tutti i caratteri di una stringa in maiuscolo.
    
    ```sql
    SELECT UPPER('ciao mondo') AS maiuscolo;
    -- Esempio output: "CIAO MONDO"
    ```
    
- **Funzioni di Conversione**
    
    Le funzioni di conversione permettono di cambiare il tipo di dati di un valore, convertendo ad esempio una stringa in un numero o una data.
    
    - **`CAST(valore AS tipo)`**: Converte un valore in un altro tipo di dato specificato.
    
    ```sql
    SELECT CAST('123' AS INTEGER) AS numero;
    -- Esempio output: 123 (numero intero)
    ```
    
- **Funzioni Condizionali**
    
    Le funzioni condizionali consentono di eseguire controlli logici e restituire risultati differenti a seconda della condizione specificata.
    
    - **`CASE WHEN`**: Valuta una condizione e restituisce un valore diverso in base alla sua veridicità.
    
    ```sql
    SELECT 
      CASE 
        WHEN score >= 90 THEN 'A'
        WHEN score >= 80 THEN 'B'
        WHEN score >= 70 THEN 'C'
        ELSE 'F'
      END AS grade
    FROM studenti;
    ```
    
    Nell'esempio, la colonna `grade` sarà assegnata un valore basato sul punteggio (`score`) di ciascuno studente.
    
- **`COALESCE(valore1, valore2, ...)`**: Restituisce il primo valore non nullo tra quelli specificati

```sql
SELECT COALESCE(NULL, NULL, 'testo predefinito', 'altro testo') AS risultato;
-- Esempio output: "testo predefinito"
```

- **`NULLIF(valore1, valore2)`**: Restituisce `NULL` se i due valori sono uguali, altrimenti restituisce il primo valore.

```sql
SELECT NULLIF(10, 10) AS risultato1, NULLIF(10, 5) AS risultato2;
-- Esempio output: risultato1 = NULL, risultato2 = 10
```

### Esempio completo

Consideriamo una tabella `utenti` con le colonne `id`, `nome`, `cognome`, `data_nascita`, e `stipendio`. La query seguente utilizza vari tipi di funzioni scalari:

```sql
SELECT 
    id,
    UPPER(nome) AS nome_maiuscolo,
    CHAR_LENGTH(cognome) AS lunghezza_cognome,
    EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM data_nascita) AS eta,
    COALESCE(stipendio, 0) AS stipendio,
    CASE 
        WHEN stipendio >= 50000 THEN 'Alto'
        WHEN stipendio >= 30000 THEN 'Medio'
        ELSE 'Basso'
    END AS fascia_stipendio
FROM utenti;

```