# 3° lezione database

Due Date: October 8, 2024
Materia: Database
REVISIONATA : No
Status: Done

# Operazioni derivate dell’algebra relazionale

## JOIN INCOMPLETI

Nel caso in cui alcuni valori tra gli attributi comuni non coincidono

![Screenshot 2024-10-09 alle 14.26.01.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-09_alle_14.26.01.png)

alcune n-uple  non partecipano al JOIN e vengono chaimate (***dangling*** n-uple).

## JOIN VUOTI

Potrebbe anche succedere che nessuna n-upla trovi il corrispettivo

![Screenshot 2024-10-09 alle 14.32.13.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-09_alle_14.32.13.png)

## PRODOTTI CARTESIANO CON LA JOIN

Date due tabelle $R_1\space R_2\space R_1\bowtie R_2$  /

![Screenshot 2024-10-10 alle 07.26.53.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-10_alle_07.26.53.png)

Ogni n-upla di $R_1$ si combina con ogni n-upla di $R_2$.  La cardinalità del risultato è il prodotto delle cardinalità.

si hanno tre varianti:

- **LEFT JOIN(sinistra)**: estrae tutti i valori della tabella a sinistra anche se non hanno corrispondenza nella tabella a destra;
    
    $$
    R\space\overleftarrow{\Join}\space S = (R \Join S)\space\cup((R - \pi_{X.Y}(R \Join S))\text{\space X \space} \{Z =NULL \})
    $$
    
- **RIGHT JOIN(destra)**: estrae tutti i valori della tabella a destra anche se non hanno corrispondenza nella tabella di sinistra

$$
R\space\overrightarrow{\Join}\space S = (R \Join S)\space\cup(X= NULL)\text{\space X \space} (S-\pi{Y.Z}(R \Join S)))
$$

![Screenshot 2024-10-11 alle 21.22.30.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_21.22.30.png)

- **FULL JOIN** estrae sia i valori della tabella di destra che quelli della taella di sinistra anche se non si ha corrispondenza

La giunzione esterna è la giunzione naturale estesa con tutte le n-uple che non appartengono alla giunzione naturale, completate con valori NULL per gli attributi mancanti.

$$

R \bowtie_{\text{full}} S = (R \bowtie S) \cup \left( (R - \pi_{X,Y} (R \bowtie S)) \times \{ Z = \text{NULL} \} \right) \cup \left( (S - \pi_{Y,Z} (R \bowtie S)) \times \{ X = \text{NULL} \} \right)

$$

## Proprietà del JOIN

- commutativo: $R \Join S  = S\Join R$ (
- Associativo: $(R \Join S)\Join T = R \Join (S \Join T)$

Da queste provette si Dens che possiamo avere le seguenze di JOIN senza rischio di ambiguità.

![Screenshot 2024-10-11 alle 21.38.50.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_21.38.50.png)

Il JOIN è definito anche se non ci sono attributi comuni fra le relazioni

In questo caso, non essendoci vincoli sulle tuple da selezionare, vengono selezionate tutte le tuple dalle relazioni del JOIN e quindi **otteniamo un prodotto cartesiano**

![Screenshot 2024-10-11 alle 21.40.17.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_21.40.17.png)

## Intersezione a partire dalla Natural Join

> Dati due relazioni definite sulla stessa lista di attributi, allora il natural join coincide con l’intersezione delle due relazioni.
> 

## SEMI-JOIN

La **semi-giunzione** (o *semi-join*) è un'operazione utilizzata nell'algebra relazionale per ridurre il numero di tuple su cui si lavora senza perdere informazioni necessarie per ulteriori elaborazioni.

Abbiamo due relazioni, R e S, con attributi distinti e condivisi. Supponiamo che:

- R sia una relazione con gli attributi X e Y (quindi R(X,Y)).
- S sia una relazione con gli attributi Y e Z (quindi S(Y,Z)).

L'operazione di semi-giunzione tra R ed S si indica come R⋉S ed è definita come una relazione contenente **solo le tuple di R** i cui valori di Y trovano corrispondenza in S (cioè ci sono tuple in S con lo stesso valore di Y).

### Differenze dalla giunzione naturale:

- Nella **giunzione naturale** R⋈S, otteniamo tutte le combinazioni di tuple di R e S che hanno lo stesso valore per l'attributo comune Y, e l'output contiene tutti gli attributi di entrambe le relazioni (X,Y,Z).
- Nella **semi-giunzione** R⋉S, invece, otteniamo **solo le tuple di R**, ma limitate a quelle che partecipano alla giunzione con S. L'output ha gli attributi X e Y, ma non Z.

### Formula della semi-giunzione

La semi-giunzione si può definire in termini di giunzione naturale seguita da una proiezione. Formalmente, la semi-giunzione R⋉S si ottiene proiettando sugli attributi di R il risultato della giunzione naturale tra R e S:

$$
R⋉S=πX,Y(R⋈S)
$$

Questa formula significa che:

1. Prima eseguiamo la **giunzione naturale** R⋈S, ottenendo tutte le coppie di tuple corrispondenti in R e Sche condividono lo stesso valore di Y.
2. Poi, applichiamo una **proiezione** sugli attributi di R (in questo caso X e Y), per ottenere solo le tuple di R che hanno una corrispondenza in S.
    
    ![Screenshot 2024-10-11 alle 23.02.18.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_23.02.18.png)
    

![Screenshot 2024-10-11 alle 23.02.49.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_23.02.49.png)

## Unione esterna

L'unione esterna tra due relazioni R ed S, definite rispettivamente sugli insiemi di attributi XY e YZ, è una tecnica che combina le due relazioni **riempiendo con valori NULL gli attributi mancanti** nelle tuple di ciascuna relazione.

### Definizione formale:

Se R(X,Y) ed S(Y,Z) sono le due relazioni, l'unione esterna si ottiene estendendo entrambe le relazioni in modo che abbiano gli stessi attributi, inserendo valori `NULL` per gli attributi che non esistono in una delle due tabelle, e poi unendo le due tabelle.

Formalmente, si può esprimere così:

$$
R∪S=(R×{Z=NULL})∪({X=NULL}×S)
$$

### Spiegazione:

- **R×Z=NULL}**: qui estendiamo la relazione RR, aggiungendo una colonna ZZ che non esiste in RR, e impostiamo tutti i valori della colonna ZZ a `NULL`. Questo ci permette di combinare RR con SS, che invece ha il campo ZZ.
- **{X=NULL}×S**: analogamente, estendiamo la relazione SS aggiungendo una colonna XX, che non esiste in SS, e impostiamo tutti i valori della colonna XX a `NULL`. In questo modo possiamo combinare SS con RR, che invece ha il campo XX.
- **Unione (∪)**: dopo aver esteso entrambe le relazioni con i valori mancanti, si esegue l'unione per ottenere una tabella finale che contenga tutte le tuple di RR e SS, completate con valori `NULL` per gli attributi mancanti in ciascuna relazione.

![image.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/image.png)

## Selezione con valori nulli

![Screenshot 2024-10-11 alle 23.20.10.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_23.20.10.png)

La condizione atomica è vera solo per valori non nulli

Consideriamo l'operazione:

$$
σETAˋ>30(P)∪σETAˋ≤30(P)≠P
$$

**Perché questo non è uguale a PP?**

Le selezioni 

$$
σETÀ>30(P)
$$

$$
σETÀ≤30(P) 
$$

vengono valutate separatamente. Ciò significa che ogni sottoinsieme viene creato prima di essere unito, e il risultato finale potrebbe non includere tutte le tuple originali.

- Se esistono tuple nel database P che non soddisfano **nessuna** delle due condizioni (ETAˋ>30 oppure ETAˋ≤30), allora queste tuple non verranno incluse nel risultato finale.
- Se ci fossero tuple con valori di ETAˋ nulli (o non validi), queste non soddisferebbero né ETAˋ>30 né ETAˋ≤30 e verrebbero escluse, motivo per cui l'unione delle due selezioni non sarebbe equivalente all'intera relazione P.

Ora vediamo l'altra espressione: 

$$
σETAˋ>30∨ETAˋ≤30(P)≠P
$$

**Perché anche questo non è uguale a PP?**

In questo caso, la condizione logica è ETAˋ>30∨ETAˋ≤30ETAˋ>30∨ETAˋ≤30, che, a prima vista, dovrebbe coprire tutte le possibilità. Ma ancora una volta, **le condizioni atomiche vengono valutate separatamente**:

Motivi:

- La condizione

$$
 ETAˋ>30∨ETAˋ≤30 
$$

copre apparentemente tutti i possibili valori numerici di ETAˋ, ma non tiene conto di eventuali valori `NULL` o valori non definiti.

- Se esistono tuple in P in cui il valore dell'attributo ETAˋ è `NULL` o mancante, queste non soddisfano né ETAˋ>30 né ETAˋ≤30, e quindi non saranno incluse nella selezione.
- Pertanto, il risultato della selezione non corrisponde all'intera relazione P, poiché le tuple con ETAˋ `NULL`verrebbero scartate.

### Soluzione

Per gestire correttamente i valori `NULL`, possiamo usare delle condizioni esplicite per fare riferimento a essi. Nella selezione, si possono utilizzare le espressioni:

- `IS NULL`: per verificare se un attributo è nullo.
- `IS NOT NULL`: per verificare se un attributo non è nullo.

### Logica a tre valori:

Nel contesto dei valori `NULL`, il confronto segue una **logica a tre valori**:

1. **Vero**: La condizione è soddisfatta.
2. **Falso**: La condizione non è soddisfatta.
3. **Sconosciuto**: Il risultato è indeterminato, tipicamente dovuto alla presenza di un valore `NULL`.

Nel nostro esempio:

- Se `Età > 40` è vero, la tupla è inclusa.
- Se `Età > 40` è falso, la tupla è esclusa.
- Se `Età` è `NULL`, il risultato del confronto è "sconosciuto", ma la condizione `Età IS NULL` può essere usata per includere queste tuple nel risultato.

![Screenshot 2024-10-11 alle 23.29.42.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_23.29.42.png)

## La divisione

La **divisione** è un operatore relazionale derivato, che consente di selezionare le tuple in una relazione RR che sono associate a **tutte** le tuple di una seconda relazione SS per un insieme comune di attributi. Formalmente, dato che la divisione non è un'operazione fondamentale dell'algebra relazionale (come la giunzione o la selezione), può essere espressa usando operatori relazionali di base.

### Definizione della divisione:

Siano:

- R(X,Y) una relazione con attributi X e Y,
- S(Y) una relazione con attributo Y in comune con R.

L'operazione di divisione R÷SR÷S restituisce una relazione con gli attributi XX, contenente tutte le tuple di XX che sono associate a **tutti i valori** di YY presenti in SS. Formalmente:

$$
R÷S={x∈πX(R)∣∀y∈S,(x,y)∈R}
$$

In altre parole, stiamo cercando tutte le tuple x nella proiezione di R su X che, combinate con ogni y∈S , formano una tupla presente in R

### Dimostrazione che la divisione è un operatore derivato:

La divisione può essere espressa usando operatori relazionali di base, come proiezione, prodotto cartesiano, differenza e giunzione. Possiamo riscriverla nei seguenti passaggi:

1. **Proiezione di RR sugli attributi XX**:πX​(R)
    
    πX(R)
    
    Questo estrae tutte le possibili tuple di XX dalla relazione RR.
    
2. **Sottrazione delle tuple che non soddisfano la condizione di divisione**: Individuiamo le tuple x∈πX(R)x∈πX(R)che **non** soddisfano la condizione richiesta dalla divisione, ovvero quelle per le quali esiste almeno un valore y∈Sy∈S tale che (x,y)∉R(x,y)∈/R. Questo si ottiene con:

$$
T=πX((πX(R)×S)−R)
$$

- genera tutte le possibili combinazioni tra le tuple di X e Y.
- Sottraendo R otteniamo le combinazioni che **non** sono presenti in R.
- Proiettando su X, otteniamo l'insieme T delle tuple x che **non** soddisfano la condizione di divisione.
- **Differenza tra la proiezione iniziale e T**: Ora, sottraiamo da $\pi_X(R)$ le tuple x che non soddisfano la condizione:

$$
R÷S=π_X	
(R)−T
$$

### Esempio di Divisione Relazionale

Consideriamo le relazioni seguenti:

- E è la relazione degli studenti che hanno seguito i corsi, con i seguenti attributi:
    - matricola: identificatore dello studente
    - corso: nome del corso seguito
- Supponiamo che i dati nella relazione EE siano i seguenti:
    
    
    | matricola | corso |
    | --- | --- |
    | 12345 | DB |
    | 12345 | PROG |
    | 67890 | DB |
    | 67890 | Rete |
    | 11223 | PROG |
    | 33445 | DB |
    | 33445 | PROG |
- S è la relazione con i corsi di interesse, in questo caso i corsi "DB" e "PROG". Quindi:
    
    S={DB,PROG}
    

### Obiettivo

Vogliamo trovare le matricole degli studenti che hanno superato **entrambi** i corsi "DB" e "PROG".

### Operazione di Divisione

Utilizziamo la divisione relazionale: matricole_superatori=πmatricola(E)÷S

### Passaggi:

1. **Proiezione di EE sulle matricole**:πmatricola​(E)={12345,67890,11223,33445}
    
    $$
    π_{matricola}(E)={12345,67890,11223,33445}
    $$
    
2. **Creazione del prodotto cartesiano**:

Creiamo il prodotto cartesiano tra

![Screenshot 2024-10-11 alle 23.47.05.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_23.47.05.png)

1. **Sottrazione di E**:
    
    Sottraiamo E per trovare le combinazioni che non sono presenti:
    
    $$
    (π_{matricola}(E)×S)−E
    $$
    
    Risultato della sottrazione:
    
    Non ci sono tuple che non soddisfano la condizione, quindi la sottrazione dà un insieme vuoto.
    

![Screenshot 2024-10-11 alle 23.51.26.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-11_alle_23.51.26.png)

La divisione della relazione A per la relazione B genera una relazione R
• avente come schema schema(A) - schema(B)
• contenente tutte le tuple di A tali che per ogni tupla (Y:y) presente in B esiste
una tupla
(X:x, Y:y) in A
• La divisione non gode né della proprietà commutativa, né della
proprietà associativa

![Screenshot 2024-10-13 alle 11.56.54.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-13_alle_11.56.54.png)

## **Viste (Relazioni derivate)**

Le viste sono un tipo di **relazioni derivate**, utilizzate per creare rappresentazioni diverse degli stessi dati all'interno di uno schema esterno.

- **Rappresentazioni diverse per gli stessi dati (schema esterno):**
    
    Lo schema esterno consente di presentare i dati in forme differenti, pur mantenendo gli stessi dati sottostanti. Le viste sono uno strumento per ottenere queste diverse rappresentazioni.
    
- **Relazioni derivate:**
    
    Le relazioni derivate sono relazioni il cui contenuto è calcolato in base al contenuto di altre relazioni. Vengono definite per mezzo di interrogazioni (query) su relazioni esistenti, siano esse di base o altre derivate.
    
- **Relazioni di base:**
    
    Queste relazioni hanno un contenuto autonomo, cioè i dati sono memorizzati direttamente e non dipendono da altre relazioni.
    
- **Dipendenza delle relazioni derivate:**
    
    Le relazioni derivate possono essere definite anche a partire da altre relazioni derivate, creando una catena di dipendenze tra i dati.
    
    ![Screenshot 2024-10-12 alle 08.26.20.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-12_alle_08.26.20.png)
    

![Screenshot 2024-10-12 alle 08.26.39.png](3%C2%B0%20lezione%20database%2011ac5c8ba93980a18d2bf91c9f04611a/Screenshot_2024-10-12_alle_08.26.39.png)

Si hanno due tipi di relazioni derivate:

- viste materizzate (non usate in questo corso):
- realzioni virtuali o viste

Sono supportate dai DBMS (tutti), una interrogazione su una vista vieneeseguita "ricalcolando" la vista.