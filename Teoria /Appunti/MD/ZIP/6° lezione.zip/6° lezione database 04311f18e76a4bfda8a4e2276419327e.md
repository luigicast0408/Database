# 6° lezione database

Due Date: October 18, 2024
Materia: Database
REVISIONATA : No
Status: Done

# Query nidificate

Le condizioni in SQL permettono anche il confronto fra un attributo e il risultato di una sotto query.

Si hanno 4 predicati per questa tipologia di query:

1. `ANY` 
2. `ALL`
3. `NOT`
4. `EXIST`

- `ANY`
    
    **Il predicato e’ vero se almeno uno dei valori restituiti dalla query soddisfano la condizione**
    
    ```sql
    SELECT P.Nome, P.Reddito
    FROM Persone P, Paternita, Persone F
    WHERE P.Nome = Padre AND Figlio = F.Nome
    AND F.Reddito > 20
    
    SELECT Nome, Reddito
    FROM Persone
    WHERE Nome in (SELECT Padre
    							FROM Paternita
    							WHERE Figlio = any (SELECT Nome
    																	FROM Persone
    																	WHERE Reddito > 20))
    ```
    
    ```sql
    SELECT P.Nome, P.Reddito
    FROM Persone P, Paternita, Persone F
    WHERE P.Nome = Padre AND Figlio = F.Nome
    AND F.Reddito > 20;
    
    SELECT Nome, Reddito
    FROM Persone
    WHERE Nome in (SELECT Padre
    							FROM Paternita, Persone
    							WHERE Figlio = Nome
    							AND Reddito > 20);
    ```
    
- `ALL`
    
    **il predicato e’ vero se tutti i valori restituiti dalla query soddisfano la condizione**
    
- `NOT EXIST`
    
    **Il predicato e’ vero se la SelectQuery restituisce almeno una tupla**
    
- `EXISTS`
    
    **Il predicato e’ vero se la SelectQuery restituisce almeno una tupla**
    
    ```sql
    SELECT *
    FROM Persone p
    WHERE EXISTS ( SELECT *
    							 FROM Paternita
    							 WHERE Padre = p. Nome)
    OR
    
    EXISTS ( SELECT *
    				FROM Maternita
    				WHERE Madre = p. Nome)
    ```
    

## Negazione con le query nidificate

![Screenshot 2024-11-06 at 14.46.59.png](6%C2%B0%20lezione%20database%2004311f18e76a4bfda8a4e2276419327e/Screenshot_2024-11-06_at_14.46.59.png)

## Operatori IN e NOT IN

- `IN`  è sinonimo di `:ANY`

```sql
select FirstName, Surname from Employee
where Dept in (select DeptName
							from Department
							where City = 'London');
```

- `NOT IN`  è sinonimo di `<>ALL`

```sql
select DeptName
from Department
where DeptName not in (select Dept
											from Employee
											where Surname = 'Brown' );
```

## MAX  e MIN con le nidificate

```sql
-- Il dipartimento(i) dove lavora colui con lo stipendio più alto di tutta l’azienda
select Dept from Employee where Salary
in (select max (Salary)
		from Employee);
-- oppure 
select Dept from Employee
where Salary >= all (select Salary 
										 from Employee);
```

**I dipartimenti che hanno una somma di salari maggiore rispetto alla somma media
dei salari dell’azienda**

```sql
SELECT Dept
FROM Emp
GROUP BY Dept
HAVING SUM(Salary) > (
					SELECT AVG(Totale.SalTot)
					FROM (SELECT SUM(Salary) ‘SalTot’
								FROM Emp
								GROUP BY Dept) AS Totale)
```

## Regole di visibilità

- **non è possibile fare riferimenti a variabili definite in blocchi più interni**
- **se un nome di variabile è omesso, si assume riferimento alla variabile più “vicina”**
- **in un blocco si può fare riferimento a variabili definite in blocchi più esterni**

```sql
SELECT *
FROM Impiegato
WHERE Dipart in (SELECT Nome
								FROM Dipartimento D1
								WHERE Nome = Produzione) 
								OR
Dipart in (SELECT Nome
					 FROM Dipartimento D2
					 WHERE D2. Citta = **D1. Citta**)
```

D1 non e’ visibile nella seconda query nidificata in quanto le due sottoquery sono allo stesso livello

## Semantica delle espressioni “correlate”

- **La query più interna può usare variabili della query esterna**
- **L’interrogazione interna viene eseguita una volta per ciascuna en-nupla dell’interrogazione esterna**

## Confronto su più attributi

Il confronto con il risultato di una query nidificata può essere basato su più attributi.

```sql
SELECT *
FROM Student S
WHERE (Nome, Cognome) IN (SELECT Nome, Cognome
													FROM Student S2
													WHERE S2. Matricola <> S. Matricola)
```

## Esempi sul quantificatore universale

- **Agenti(CodiceAgente,Nome,Zona Supervisore,Commissione)**
- **Clienti(CodiceCliente,Nome,Citta’,Sconto)**
- **Ordini(CodiceOrdine,CodiceCliente,CodiceAgente,Articolo,Data,Ammontare)**

```sql
-- trovare i codici di quei clienti che hanno fatto ordini a TUTTI gli agenti di Catania.
SELECT C. CodiceCliente
FROM Clienti C
WHERE NOT EXISTS
	(SELECT *
	 FROM Agenti A
	 WHERE A. Zona = 'Catania'
	AND NOT EXISTS
	(SELECT *
		FROM Ordini v
		WHERE V. CodiceCliente = C. CodiceCliente
		AND V. CodiceAgente = A. CodiceAgente) )
```

Supponiamo di avere quest’ altro schema 

- **City(id,city,country,district,population**
- **Cities_Stores(city,store_type,address)**
- **Stores(store_type,description)**

```sql
-- quali tipi di negozi sono presenti in una città
SELECT DISTINCT store_type
FROM Stores WHERE EXISTS
									(SELECT * FROM Cities_Stores WHERE
									Cities_ Stores. store_type = Stores. store_type)
```

```sql
-- quali tipi di negozi non  sono presenti in una città
SELECT DISTINCT store_ type
FROM Stores 
WHERE NOT EXISTS
							(SELECT * 
							FROM Cities_Stores
							WHERE Cities_ Stores. store_type = Stores. store_type)
```

```sql
SELECT DISTINCT store_type 
FROM Stores
WHERE NOT EXISTS (
SELECT * FROM Cities WHERE
NOT EXISTS (
				SELECT * FROM Cities_Stores
				WHERE Cities_Stores.city = Cities.city AND Cities_Stores.store_type = Stores.store_type) )
```